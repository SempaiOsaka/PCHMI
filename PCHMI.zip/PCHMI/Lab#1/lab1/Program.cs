﻿using System;
using System.Linq;
using System.Text.Json;

namespace lab1
{
    public class Program
    {     
        static void Main(string[] args)
        {
            string typeSer = Console.ReadLine(); //вводим тип сериализации Json или xml
            string InputString = Console.ReadLine(); //вводим объект сериализации

            ISerializer serializer;
            //улсловие на выбор типа сериализации
            if (typeSer == "Json")
                serializer = new JsonSerialize(); 
            else
                serializer = new XMLSerializer();

            Output kek = new Output(); //объект вывода

            Input kekW = serializer.Deserialize<Input>(InputString); //десериализуем объект ввода, чтобы подсчитать сумму, произведение и отортировать все это
            kek.SumResult = kekW.Sums.Sum() * kekW.K; //сумма умноженная на коэффициент K
            kek.MulResult = 1;
            for (int i = 0; i < kekW.Muls.Length; i++)
            {
                kek.MulResult *= kekW.Muls[i]; //произведение
            }
          
            kek.SortedInputs = new decimal[kekW.Sums.Length + kekW.Muls.Length]; // задаем длинну массиву
            for (int i = 0; i < kekW.Sums.Length; i++)
            {
                kek.SortedInputs[i] = kekW.Sums[i]; //заполняем массив значениями из Sums
            }

            for (int i = 0; i < kekW.Muls.Length; i++)
            {
                kek.SortedInputs[kekW.Sums.Length + i] = kekW.Muls[i]; //заполняем массив значениями из Muls
            }
            Array.Sort(kek.SortedInputs); //сортируем

            string asd = serializer.Serialize(kek); //сериализуем получившийся объект 
            Console.WriteLine(asd);

            Console.ReadKey();
        }
    }


}
