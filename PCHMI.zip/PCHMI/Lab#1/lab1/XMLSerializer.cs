﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace lab1
{//класс для сериализации типа XML
    public class XMLSerializer : ISerializer
    {
        //метод сериаизации
        public string Serialize<T>(T obj)
        {            
            var formatter = new XmlSerializer(typeof(T)); //создаем экземпляр класса для сериализации объекта
            StringWriter textWriter = new StringWriter(); //создаем экземпляр класса для записи объекта
            formatter.Serialize(textWriter, obj); //сериализуем объект
            return textWriter.ToString(); //возвращаем объект в виде строки
        }

        //метод десериализации
        public T Deserialize<T>(string json)
        {
            var formatter = new XmlSerializer(typeof(T)); //создаем экземпляр класса для сериализации объекта
            byte[] byteArray = Encoding.UTF8.GetBytes(json); //преобразуем строку в массив в байт, чтобы хранить ее в потоке данных
            MemoryStream stream = new MemoryStream(byteArray);
            return (T)formatter.Deserialize(stream);
        }
    }
}

