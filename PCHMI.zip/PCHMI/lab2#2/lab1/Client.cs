﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace lab1
{
    public class Client
    {
        WebClient webClient; 
        String Url;

        public Client(String port)
        {
            webClient = new WebClient(); //экземпляр класса для обмена данными
            Url = "http://127.0.0.1:" + port; //будем отправлять запрос себе
            
            //Url = "http://91.245.227.5" + port;
        }

        public bool Ping()
        {
            try
            {
                webClient.DownloadData(Url + "/Ping"); //получаем статус сервера
                return true;
            }
            catch (WebException)
            {
                return false;
            }
        }

        public Input getInputData()
        {
            byte[] inputData;
            string inputDataStr;
            inputData = webClient.DownloadData(Url + "/GetInputData"); //получаем данные с ресурса в виде массива байтов
            inputDataStr = Encoding.UTF8.GetString(inputData); //декодируем в строку
            ISerializer serializer = new JsonSerialize();
            Input input = serializer.Deserialize<Input>(inputDataStr);// десериализуем
            return input;
        }

        public void writeAnswer(Output output)
        {
            byte[] outputData;
            ISerializer serializer = new JsonSerialize();
            string outputDataStr = serializer.Serialize<Output>(output); //сериализуем объект
            outputData = Encoding.UTF8.GetBytes(outputDataStr); //кодируем наш объект в байты 
            webClient.UploadData(Url + "/WriteAnswer", outputData); //отправлем серверу наш объект 
        }
    }
}
