﻿using System;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.Json;

namespace lab1
{
    public class Program
    {    

        static void Main(string[] args)
        {
            Client client = new Client(Console.ReadLine()); //вводим порт
            while (client.Ping() != true); //проверка на работу сервера, если он будет выключен, то будет выводиться исключение
 
            ISerializer serializer;           
            serializer = new JsonSerialize();


            Output kek = new Output();
            Input kekW = client.getInputData();
            kek.SumResult = kekW.Sums.Sum() * kekW.K;
            kek.MulResult = 1;
            for (int i = 0; i < kekW.Muls.Length; i++)
            {
                kek.MulResult *= kekW.Muls[i];

            }

            kek.SortedInputs = new decimal[kekW.Sums.Length + kekW.Muls.Length];
            for (int i = 0; i < kekW.Sums.Length; i++)
            {
                kek.SortedInputs[i] = kekW.Sums[i];
            }

            for (int i = 0; i < kekW.Muls.Length; i++)
            {
                kek.SortedInputs[kekW.Sums.Length + i] = kekW.Muls[i];
            }
            Array.Sort(kek.SortedInputs);

            string asd = serializer.Serialize(kek);

            client.writeAnswer(kek);

            Console.WriteLine(asd);

            Console.ReadKey();
        }
    }


}
